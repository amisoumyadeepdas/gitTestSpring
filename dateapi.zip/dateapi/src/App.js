import React, { Component,useState } from 'react';
import API from './services/dateAPI';
import DateButton from './components/DateButton';
import DateDisplay from './components/DateDisplay';
const DATE_JSON_URL = 'https://jsonmock.hackerrank.com/datetime';

function App() {
  const[apiResponse,setApiResponse]=useState(null)
  const[year,setYear]=useState(null)
  const[month,setMonth]=useState("")
  const[day,setDay]=useState("")
  // constructor() {
  //   super();
  //   this.state= {
  //     apiResponse: ''
  //   };
  // }

  const handleButtonClick = async () => {
    const res= await fetch(DATE_JSON_URL);
    const data=await res.json();
    console.log(data.date);
    console.log(year);
    const i=data.date;
    setYear(i.substring(0,2));
    setMonth(data.date.substring(3,5));
    setYear(data.date.substring(6,10));

    console.log(year);
    
    setApiResponse(data);
  }


    return (
      <div>
        <center><h1>Date API</h1></center>
        <center><DateButton handelClick={handleButtonClick}></DateButton></center>
        <DateDisplay response={apiResponse} ></DateDisplay>
      </div>
    );
  
}

export default App;
