import React from 'react';
import PropTypes from 'prop-types';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import { Paper } from '@mui/material';

function DateDisplay({response}) {

  if(!response){
    return(
      <Paper className="container">
        <List>
            <ListItem>
              <ListItemText data-testid="day">Day: </ListItemText>
            </ListItem>
            <ListItem>
                <ListItemText data-testid="month">Month: </ListItemText>
            </ListItem>
            <ListItem>
              <ListItemText data-testid="year" primary="Year:">Year: </ListItemText>
            </ListItem>
        </List>
      </Paper>
    );
  }

  return(
  <Paper className="container">
      <List>
          <ListItem>
            <ListItemText data-testid="day" primary={`Day: ${response.time}`}></ListItemText>
          </ListItem>
          <ListItem>
              <ListItemText data-testid="month" primary={`Month: ${response.date}`}></ListItemText>
          </ListItem>
          <ListItem>
             <ListItemText data-testid="year" primary="Year:" />
          </ListItem>
      </List>
  </Paper>
  );
}

export default DateDisplay;